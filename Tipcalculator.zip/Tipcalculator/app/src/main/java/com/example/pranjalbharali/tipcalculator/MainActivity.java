package com.example.pranjalbharali.tipcalculator;

/**
 * Created by pranjalbharali on 15/03/2018.
 */

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import static com.example.pranjalbharali.tipcalculator.R.id.taste1;


public class MainActivity extends Activity {


    RadioButton Taste1;
    RadioButton Taste2;
    RadioButton Taste3;
    RadioButton Service1;
    RadioButton Service2;
    RadioButton Service3;

    String tag = "Tip Converter Log";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        super.onCreate(savedInstanceState);
        //display the main screen
        setContentView(R.layout.activity_main);


        final EditText tipValueEntered = (EditText)findViewById(R.id.TipValueEntered);
        Taste1 = (RadioButton)findViewById(R.id.taste1);
        Taste2 = (RadioButton)findViewById(R.id.taste2);
        Taste3 = (RadioButton)findViewById(R.id.taste3);
        Service1 = (RadioButton)findViewById(R.id.service1);
        Service2 = (RadioButton)findViewById(R.id.service2);
        Service3 = (RadioButton)findViewById(R.id.service3);

        Button calculateButton = (Button)findViewById(R.id.calculateTip);

        final TextView ValueCalculated = (TextView)findViewById(R.id.TipValueCalc);
        final TextView wholePayment = (TextView)findViewById(R.id.wholePayment);


        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                {
                    try {
                        String valueEntered = tipValueEntered.getText().toString();
                        Double valueConverted = Double.parseDouble(valueEntered);
                        Double multiplier = checkRadioButtons();
                        Log.i(tag,"The multiplier is: " + multiplier.toString());
                        valueConverted = ((double) Math.round(valueConverted * multiplier));
                        Double wholepayment = valueConverted + Double.parseDouble(valueEntered);
                        ValueCalculated.setText("Here is the tip : " + valueConverted.toString()+"$");
                        wholePayment.setText("Your total payment : " + wholepayment + "$");
                    }
                    catch (Exception e)
                    {
                        Log.i(tag,"The program was interrupted in calculateButton method, exception: " + e.getMessage());
                    }
                }}});}

    public Double checkRadioButtons( )
    {
        double coefficient = 0;
        if (Taste1.isChecked())
        {
            coefficient += 0.2;
            Log.i(tag,"Food is Very good! Tip is higher by 20%");
        }
        if (Taste2.isChecked())
        {
            coefficient += 0.1;
            Log.i(tag,"Food is Average! Tip is higher by 10%");
        }
        if (Service1.isChecked())
        {
            coefficient += 0.3;
            Log.i(tag,"Service was Very good! The tip is higher by 30%");
        }
        if (Service2.isChecked())
        {
            coefficient += 0.2;
            Log.i(tag,"Service was Average! The tip is higher by 20%");
        }
        return coefficient;
    };
}
